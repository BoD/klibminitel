// Generated file. Do not edit!
package org.jraf.klibminitel
import kotlin.jvm.JvmField
@JvmField
val VERSION = "1.4.1"
